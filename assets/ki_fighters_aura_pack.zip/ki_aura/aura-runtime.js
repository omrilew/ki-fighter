/* Ki Fighters illustrated aura renderer. Add this script after the game's canvas setup.
 * Usage: const aura = new KiIllustratedAura('assets/auras/');
 * aura.draw(ctx, player.x, player.y, player.surge?'gold':'blue', elapsedCharge, storyClock);
 * Draw BEFORE the player sprite. Coordinates are feet anchored.
 */
class KiIllustratedAura {
  constructor(base='assets/auras/') {
    this.images={};this.base=base;
    for(const color of ['blue','gold'])for(const stage of ['start','mid','strong','full']) {
      const key=color+'_'+stage,img=new Image();img.decoding='async';img.src=base+key+'.png';this.images[key]=img;
    }
  }
  draw(ctx,x,y,color,elapsed,time) {
    if(color!=='blue'&&color!=='gold')return;
    const stage=elapsed<.3?'start':elapsed<.9?'mid':elapsed<1.6?'strong':'full';
    const im=this.images[color+'_'+stage];if(!im?.complete||!im.naturalWidth)return;
    const dims={start:[46,56],mid:[61,77],strong:[70,95],full:[83,112]};
    const [w,h]=dims[stage];
    ctx.save();ctx.imageSmoothingEnabled=false;
    const pulse=1+.018*Math.sin(time*15);
    ctx.globalAlpha=.91+.07*Math.sin(time*12);
    ctx.drawImage(im,Math.round(x-w*pulse/2),Math.round(y-h*pulse+6),Math.round(w*pulse),Math.round(h*pulse));
    ctx.restore();
  }
}
if(typeof window!=='undefined')window.KiIllustratedAura=KiIllustratedAura;
