# Ki Fighters illustrated aura pack

Four blue and four gold aura images, transparent PNG, each cropped from a generated illustrated reference. `aura-runtime.js` preloads the eight images and draws the aura at the player's feet position. It does not create a game loop or duplicate the character. Draw before the fighter sprite.

Integration steps:
1. Copy eight PNGs into `assets/auras/` and `aura-runtime.js` to the game's static root.
2. Include `<script src="aura-runtime.js"></script>` before the main game script.
3. Construct `const illustratedAura = new KiIllustratedAura('assets/auras/');` once during initialization.
4. In the existing aura render pass, use `illustratedAura.draw(c,p.x,p.y,p.surge?'gold':'blue',storyClock-p._auraChargeSince,storyClock)` while charging. For idle normal, draw nothing; SSJ idle can use low-opacity start-stage separately.
5. Remove/disable `pixel-aura.js` and its prior aura renderer after successful integration.
6. Visually verify feet alignment, clipping, charging stages, all directions, and mobile FPS.

Note: Four illustrated intensity stages, not a true eight-frame hand-animated cycle. Runtime uses subtle pulse between stages. Transparent background is extracted from a generated near-white image, so verify edge halos in-game.
